#otro modulo

mi_lista = [1,2,3,4,5]

mi_diccionario = {'valores' : mi_lista}

a = 1