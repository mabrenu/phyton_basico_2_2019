# ejemplo de módulo en subfolder
a = 1
b = 1

class Pato:
    def __init__(self):
        print('Soy un pato')

    def camina(self):
        print('El pato camina')