#esto es un módulo

#definiciones de funciones
def suma_resta(a,b,c):
    return a + b -c

flambda1 = lambda x, y : x + 10 * y
